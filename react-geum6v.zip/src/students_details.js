export const students = [{
            "student_id": "F1215",
            "student_first_name": "Cammy",
            "student_Last_name": "Albares",
            "student_address": "56 E Morehead St",
            "student_city": "Laredo",
            "student_county": "Webb",
            "student_state": "TX",
            "zip": "78045",
            "Age": "20",
            "DOB": "1/4/1999",
            "Subjects": [
              {"English": "A"},
              {"Maths": "A"},
              {"Science": "B"},
              {"Computer Science": "B"},
              {"Social Science": ""}
            ]
          },
          {
            "student_id": "F1208",
            "student_first_name": "Leota",
            "student_last_name": "dilliard",
            "student_address": "7 W Jackson Blvd",
            "student_city": "San Jose",
            "student_county": "Santa Clara",
            "student_state": "CA",
            "zip": "95111",
            "Age": "20",
            "DOB": "4/17/1999",
            "Subjects": [
              {"English": "A"},
              {"Maths": "A"},
              {"Science": "C"},
              {"Computer Science": ""},
              {"Social Science": ""}
            ]
          },
          {
            "student_id": "F1223",
            "student_first_name": "Willard",
            "student_last_name": "Kolmetz",
            "student_address": "618W Yakima Ave",
            "student_city": "Irving",
            "student_county": "Dallas",
            "student_state": "TX",
            "zip": "75062",
            "DOB": "",
            "Age": "14",
            "Subjects": [
              {"English": "A"},
              {"Maths": "A"},
              {"Science": ""},
              {"Computer Science": "B"},
              {"Social Science": ""}
            ]
          },
          {
            "student_id": "F1222",
            "student_first_name": "John",
            "student_last_name": "Micheal",
            "student_address": "6 Greenleaf Ave",
            "student_city": "San Jose",
            "student_county": "Santa Clara",
            "student_state": "CA",
            "zip": "95111",
            "Age": "18",
            "DOB": "",
            "Subjects": [
              {"English": "A"},
              {"Maths": ""},
              {"Science": "B"},
              {"Computer Science": "B"},
              {"Social Science": ""}
            ]
}];