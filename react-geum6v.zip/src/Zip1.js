import React from 'react';

const Zip = (props) => {
  return(
    props.result.map(
      results => <div>
      <h1 key={results.player_first_name}>{results.player_first_name} {results.player_last_name}</h1>

      <h4 key={results.player_last_name}>Show list Sports: {results.length && results.Sports_games.map(g => { var visibility = (check && g[Object.keys(g)[0]]) ? 'block' : 'none'; console.log(g[Object.keys(g)[0]]); return <div style={{display: visibility}}>{Object.keys(g)[0]} {g[Object.keys(g)[0]]}</div> } )}</h4><br/><br/>

      // This is not a perfect key, but given the values at hand
      </div> 
      )

      
    
      
      
  )
}

export default Zip1;