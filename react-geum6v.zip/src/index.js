import React, { Component } from 'react';
import { render } from 'react-dom';
import StudentZip from './StudentZip';
import Zip1 from './Zip1';
import { students } from './students_details';
import './style.css';

class App extends Component {
  constructor() {
    super();
    this.state = {
      result: [],
      student_zip1: "0",
      student_dob1: "0",
      student_age1: "0",
      student_state1: "select",
      student_min_grade: "select",
      student_max_grade: "select",
      check: true,
      student_zipValue: false
    }

    this.students_zip_serach = this.studentsZipSearch.bind(this);
    this.calculate_age = this.calculate_age.bind(this);
    this.handleChange_zip = this.handleChange_zip.bind(this);
    this.handleChange_age = this.handleChange_age.bind(this);
    this.handleChange_state = this.handleChange_state.bind(this);
    this.handleChange_sub = this.handleChange_sub.bind(this);
    this.handleChange_mingrade = this.handleChange_mingrade.bind(this);
    this.handleChange_maxgrade = this.handleChange_maxgrade.bind(this);
  }

  handleChange_zip = (event) => {
    console.log("Zip Number:", event.target.value);

    this.setState({ student_zip1: event.target.value })
  }
  handleChange_age = (event) => {
    console.log("DOB:", event.target.value);

    this.setState({ student_dob1: event.target.value }, () => {
      // example of setState callback
      // this will have the latest this.state.student_dob1
      console.log(this.state.student_dob1);
    })

    // call calculate_age with event.target.value
    var age_latest = {age_latest: this.calculate_age(event.target.value)}
    console.log(age_latest);

    this.setState({ student_age1: age_latest }, () => {
      // this will have the latest this.state.student_age1
      console.log("Age:", this.state.student_age1);
    })
  }
  handleChange_state = (event) => {
    console.log("State:", event.target.value);

    this.setState({ student_state1: event.target.value });
  }
  handleChange_sub = (event) => {
    console.log("check:", event.target.value);

    this.setState({ check: event.target.value })
    
  }
  handleChange_mingrade = (event) => {
    console.log("min grade:", event.target.value);

    this.setState({ student_min_grade: event.target.value });
  }
  handleChange_maxgrade = (event) => {
    console.log("max_grade:", event.target.value);

    this.setState({ student_max_grade: event.target.value });
  }

  calculate_age = (student_dob1) => {
    var today = new Date();
    var birthDate = new Date(student_dob1);  // create a date object directly from `dob1` argument
    var age_now = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) 
    {
        age_now--;
    }
    console.log(age_now);
    return age_now;
  }

  studentsZipSearch = () => {
    const { student_zip1, student_dob1, student_age1, student_state1, check } = this.state;

    const newArray = students.filter((el) => { return ((el.zip === student_zip1) && (parseInt(el.Age) <= parseInt(student_age1[Object.keys(student_age1)[0]])) && (el.student_state != (student_state1)) && check ) });
    //const newArray1 = newArray[0].Subjects.map((el1) => { return Object.keys(el1) });
    //const sorted = newArray1[Object.keys(newArray1)].sort();
    //console.log(student_age1);
    //console.log(student_zip1);
    console.log("here--", this.state.student_zip1, this.state.student_age1);
    console.log(newArray);
    //console.log(newArray1);
    //console.log(sorted);
    //console.log(newArray.Subjects);
    this.setState({ result: newArray, student_zipValue: true })
  }

  render() {
    const { name, result, student_zip1, student_zipValue, student_age1, student_dob1, student_state1, check, student_min_grade, student_max_grade } = this.state;

    return (
      <div>

        <h2>STUDENTS DEMOGRAPHIC DETAILS</h2>

        
          Students Belonging to same zip code:
         <input type="text" name="zip_code" defaultValue={student_zip1} onChange={this.handleChange_zip}></input> <br /><br />

          Number of male over certain age: <input type="date" name="date_of_birth" defaultValue= {student_dob1} onChange={this.handleChange_age}></input> <br /><br />

          Students not Belonging from a given state: 
          <select value={student_state1} onChange={this.handleChange_state}>
            <option value="select">Select</option>
            <option value="CA">CA</option>
            <option value="TX">TX</option>
          </select><br/><br/>

          List of Subjects received grades: <input type="checkbox" name="subjects" value={check} onChange={this.handleChange_sub}></input><br/><br/>

          Students received a grade within a range: 
          min grade:<select value={student_min_grade} onChange={this.handleChange_mingrade}>
            <option value="select">Select</option>
            <option value="A">A</option>
            <option value="B">B</option>
            <option value="c">C</option>
          </select>
          max_grade:<select value={student_max_grade} onChange={this.handleChange_maxgrade}>
            <option value="select">Select</option>
            <option value="A">A</option>
            <option value="B">B</option>
            <option value="c">C</option>
          </select><br/><br />

          <button onClick={this.studentsZipSearch.bind(this)}>Submit</button><br />
          {student_zipValue && <StudentZip result={result} />}
          
      </div>
    );
  }
}

render(<App />, document.getElementById('root'));