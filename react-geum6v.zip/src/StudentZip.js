import React from 'react';

const StudentZip = (props) => {
  return(
    props.result.map(
      results => <div>
      <h1 key={results.student_first_name}>{results.student_first_name} {results.student_last_name}</h1>

      Show list Subjects: { results.Subjects.map(g => { var check = true; var visibility = (check && g[Object.keys(g)]) ? 'block' : 'none'; console.log(g[Object.keys(g)]); return <div style={{display: visibility}}>{Object.keys(g)} {g[Object.keys(g)]}</div> } )}<br/><br/>

      Students with Highest Grade: {results.Subjects.map(g => { var check = true; var visibility = (check && g[Object.keys(g)] === "A") ? 'block' : 'none'; console.log(g[Object.keys(g)]);return <div style={{display: visibility}}>{Object.keys(g)} {g[Object.keys(g)]}</div> } )} <br/><br/>

      Students with range of Sport games grades : {results.Subjects.map(g => { var check= true; var new_Array2 = Object.keys(g).concat(g[Object.keys(g)]); console.log(new_Array2); var new_Array3 = new_Array2.sort(); console.log(new_Array3);var new_Array4 = { '{Object.keys(g)}' :(g[Object.keys(g)])}; console.log(new_Array4); var new_Array5 = Object.keys(new_Array4).sort(function (a,b){return a.g[Object.keys(g)] - b.g[Object.keys(g)]}); console.log("ass", new_Array5); var visibility = (check && g[Object.keys(g)]) ? 'block' : 'none'; var sorted = {sorted:(visibility && g[Object.keys(g)])}; console.log(sorted);return <div style={{display: visibility}}>{Object.keys(g)} {g[Object.keys(g)]}</div> } )} <br/><br/>

      </div> 
    )     
  )
}

export default StudentZip;