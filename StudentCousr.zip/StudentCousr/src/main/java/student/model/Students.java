package student.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Students implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3931158801192373915L;
	
	@Id
	private String sports_id;
	@Column
	private String player_first_name;
	@Column
	private String last_name;
	@Column
	private String sports_address;
	@Column
	private String sports_city;
	@Column
	private String sports_county;
	@Column
	private String sports_state;
	@Column
	private String zip;
	@Column
	private Integer age;
	
	@Override
	public String toString() {
		return "Students [sports_id=" + sports_id + ", player_first_name=" + player_first_name + ", last_name="
				+ last_name + ", sports_address=" + sports_address + ", sports_city=" + sports_city + ", sports_county="
				+ sports_county + ", sports_state=" + sports_state + ", zip=" + zip + ", age=" + age + "]";
	}
	
	public String getSports_id() {
		return sports_id;
	}
	public void setSports_id(String sports_id) {
		this.sports_id = sports_id;
	}
	public String getPlayer_first_name() {
		return player_first_name;
	}
	public void setPlayer_first_name(String player_first_name) {
		this.player_first_name = player_first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getSports_address() {
		return sports_address;
	}
	public void setSports_address(String sports_address) {
		this.sports_address = sports_address;
	}
	public String getSports_city() {
		return sports_city;
	}
	public void setSports_city(String sports_city) {
		this.sports_city = sports_city;
	}
	public String getSports_county() {
		return sports_county;
	}
	public void setSports_county(String sports_county) {
		this.sports_county = sports_county;
	}
	public String getSports_state() {
		return sports_state;
	}
	public void setSports_state(String sports_state) {
		this.sports_state = sports_state;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	
	
	
	
	

}
