package student.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import student.model.Students;
import student.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	StudentRepository studentRepo;

	@Override
	public void saveStudents(Students student) {
		studentRepo.save(student);
	}

	@Override
	public List<Students> getAllStudents() {
		List<Students> studentList = new ArrayList<>();
		studentRepo.findAll().forEach(studentList::add);
		return studentList;
	}

	@Override
	public List<Students> saveAllStudent(List<Students> studentList) {
		// TODO Auto-generated method stub
		List<Students> addedList = new ArrayList<>();
		//return studentRepo.save(studentList.iterator());
		studentRepo.save(studentList).forEach(addedList::add);
		return addedList;
	}

}
