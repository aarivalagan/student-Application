package student.service;

import java.util.List;

import student.model.Students;

public interface StudentService {
	
	public void saveStudents(Students student);
	
	public List<Students> getAllStudents();
	
	public List<Students> saveAllStudent(List<Students> studentList);

}
