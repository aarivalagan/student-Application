package student.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import student.model.Students;
import student.service.StudentService;

@RestController
public class CourseController {
	
	private static String UPLOADED_FOLDER = "F://";

	
	
	@Autowired
	StudentService studentService;
	
	@GetMapping("/hello")
	public @ResponseBody List<Students> Hello() {
		
		return null;
	}
	
	@PostMapping("/upload") 
	public @ResponseBody List<Students> uplloadExcelFile(@RequestParam("file") MultipartFile file) throws Exception  {
		 List<Students> studentList = new ArrayList<>();
		 if( studentService.getAllStudents().size() > 0) {
			 return studentService.getAllStudents();
		 }
		try {

            // Get the file and save it somewhere
            byte[] bytes = file.getBytes();
            Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
            Files.write(path, bytes);
            Workbook workbook = WorkbookFactory.create(new File(UPLOADED_FOLDER + file.getOriginalFilename()));
            Sheet sheet = workbook.getSheetAt(0);
            DataFormatter dataFormatter = new DataFormatter();
           
            for (Row row: sheet) {
            	String cellValue = dataFormatter.formatCellValue(row.getCell(0));
            	System.out.print(cellValue + "\t");
            	Students student = new Students();
            	student.setSports_id(dataFormatter.formatCellValue(row.getCell(0)));
            	student.setSports_address(dataFormatter.formatCellValue(row.getCell(1)));
            	student.setSports_city(dataFormatter.formatCellValue(row.getCell(2)));
            	student.setSports_county(dataFormatter.formatCellValue(row.getCell(3)));
            	student.setSports_state(dataFormatter.formatCellValue(row.getCell(4)));
            	student.setZip(dataFormatter.formatCellValue(row.getCell(5)));
                System.out.println(student);
                studentList.add(student);
            }
            studentList =  studentService.saveAllStudent(studentList);
            workbook.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
		
		return studentList;
	}
	
	@GetMapping("/students") 
	public @ResponseBody List<Students> getAllStudents() {
		return studentService.getAllStudents();
	}
	
	
	
	

}
