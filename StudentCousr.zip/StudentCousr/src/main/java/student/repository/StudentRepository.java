package student.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import student.model.Students;

@Repository
public interface StudentRepository  extends CrudRepository<Students, String>{
	
}
